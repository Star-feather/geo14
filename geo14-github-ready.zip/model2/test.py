import argparse
import os, sys
from scipy.spatial.transform import Rotation as R
from utils.opt import Options
import numpy as np
from model2.config import config
from model2.model import siMLPe as Model
# from h36m_eval import H36MEval
from utils.h36motion3d import Datasets as H36MEval
# from utils.misc import rotmat2xyz_torch, rotmat2euler_torch

import torch
from torch.utils.data import DataLoader

results_keys = ['#2', '#4', '#8', '#10', '#14', '#18', '#22', '#25']

def get_dct_matrix(N):
    dct_m = np.eye(N)
    for k in np.arange(N):
        for i in np.arange(N):
            w = np.sqrt(2 / N)
            if k == 0:
                w = np.sqrt(1 / N)
            dct_m[k, i] = w * np.cos(np.pi * (i + 1 / 2) * k / N)
    idct_m = np.linalg.inv(dct_m)
    return dct_m, idct_m

dct_m,idct_m = get_dct_matrix(config.motion.h36m_input_length_dct)
dct_m = torch.tensor(dct_m).float().cuda().unsqueeze(0)
idct_m = torch.tensor(idct_m).float().cuda().unsqueeze(0)

def regress_pred(model, pbar, num_samples, joint_used_xyz, m_p3d_h36):
    joint_to_ignore = np.array([16, 20, 23, 24, 28, 31]).astype(np.int64)
    joint_equal = np.array([13, 19, 22, 13, 27, 30]).astype(np.int64)
    motion_pred = None
    for (motion_input, motion_target) in pbar:
        motion_input = motion_input.cuda()
        b,n,c,_ = motion_input.shape
        num_samples += b

        motion_input = motion_input.reshape(b, n, 32, 3)
        motion_input = motion_input[:, :, joint_used_xyz].reshape(b, n, -1)
        outputs = []
        step = config.motion.h36m_target_length_train
        if step == 25:
            num_step = 1
        else:
            num_step = 25 // step + 1
        for idx in range(num_step):
            with torch.no_grad():
                if config.deriv_input:
                    motion_input_ = motion_input.clone()
                    motion_input_ = torch.matmul(dct_m[:, :, :config.motion.h36m_input_length], motion_input_.cuda())
                else:
                    motion_input_ = motion_input.clone()
                output = model(motion_input_)
                output = torch.matmul(idct_m[:, :config.motion.h36m_input_length, :], output)[:, :step, :]
                if config.deriv_output:
                    output = output + motion_input[:, -1:, :].repeat(1,step,1)

            output = output.reshape(-1, 22*3)
            output = output.reshape(b,step,-1)
            outputs.append(output)
            motion_input = torch.cat([motion_input[:, step:], output], axis=1)
        motion_pred = torch.cat(outputs, axis=1)[:,:25]

        motion_target = motion_target.detach()
        b,n,c,_ = motion_target.shape

        motion_gt = motion_target.clone()

        motion_pred = motion_pred.detach()#.cpu()
        pred_rot = motion_pred.clone().reshape(b,n,22,3)
        motion_pred = motion_target.clone().reshape(b,n,32,3)
        motion_pred[:, :, joint_used_xyz] = pred_rot

        tmp = motion_gt.clone()
        tmp[:, :, joint_used_xyz] = motion_pred[:, :, joint_used_xyz]
        motion_pred = tmp
        motion_pred[:, :, joint_to_ignore] = motion_pred[:, :, joint_equal] # 需要这个 （bs,seq,66）

        mpjpe_p3d_h36 = torch.sum(torch.mean(torch.norm(motion_pred - motion_gt, dim=3), dim=2), dim=0)
        motion_pred = motion_pred.reshape(b,n,-1)
        m_p3d_h36 += mpjpe_p3d_h36.cpu().numpy()
    m_p3d_h36 = m_p3d_h36 / num_samples
    return m_p3d_h36,motion_pred

def test(config, model, dataloader) :
    m_p3d_h36 = np.zeros([config.motion.h36m_target_length])
    titles = np.array(range(config.motion.h36m_target_length)) + 1
    joint_used_xyz = np.array([2,3,4,5,7,8,9,10,12,13,14,15,17,18,19,21,22,25,26,27,29,30]).astype(np.int64)
    num_samples = 0
    for i, (p3d_h36) in enumerate(dataloader):
        # print(i)
        batch_size, seq_n, all_dim = p3d_h36.shape
        if batch_size == 1:
            continue
        # n += batch_size
        p3d_h36 = p3d_h36.float().to(opt.cuda_idx).reshape(batch_size,seq_n,32,-1)
        input_data = p3d_h36[:, :10 ].clone()
        target_data = p3d_h36[:, 10:35 ].clone()
        pbar = [(input_data,target_data)]
        # pbar = dataloader
        m_p3d_h36,motion_pred = regress_pred(model, pbar, num_samples, joint_used_xyz, m_p3d_h36)

        ret = {}
        for j in range(config.motion.h36m_target_length_eval):
            ret["#{:d}".format(titles[j])] = [m_p3d_h36[j], m_p3d_h36[j]]
        return [round(ret[key][0], 1) for key in results_keys]

def test_one(motion_input,model,config):
    motion_input = motion_input.cuda()
    b, n, c = motion_input.shape

    idx = list(range(n)) + [n - 1] * (config.motion.h36m_input_length - n)
    motion_input = motion_input[:, idx].clone() # (b,h36m_input_length,c)
    step = config.motion.h36m_target_length_train  # 35

    with torch.no_grad():
        if config.deriv_input:
            motion_input_ = motion_input.clone()
            motion_input_ = torch.matmul(dct_m[:, :, :config.motion.h36m_input_length], motion_input_.cuda())
        else:
            motion_input_ = motion_input.clone()

        output = model(motion_input_)
        output = torch.matmul(idct_m[:, :config.motion.h36m_input_length, :], output)[:, :step, :]

        if config.deriv_output:
            output[:,:n] += motion_input[:, :n, :]
            output[:,n:] += motion_input[:, -1:, :].repeat(1,step - n,1)

    output = output.reshape(-1, 22 * 3)
    output = output.reshape(b, step, -1)
    return output


if __name__ == "__main__":
    opt = Options().parse()
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    # parser.add_argument('--model-pth', type=str, default=None, help='=encoder path')
    # args = parser.parse_args()
    model = Model(config)
    model_pth = 'D:\Ai\siMLPe-main\exps/baseline_h36m\log\snapshot\model-iter-40000.pth'
    state_dict = torch.load(model_pth, map_location='cpu') #, weights_only=True
    # Support the module names used in the released H36M checkpoints.
    state_dict = {
        key.replace('motion_transformer.transformer.', 'motion_mlp.mlps.'): value
        for key, value in state_dict.items()
    }
    model.load_state_dict(state_dict, strict=True)
    model.eval()
    model.cuda()
    ACTIONS = [
        "walking", "eating", "smoking", "discussion", "directions",
        "greeting", "phoning", "posing", "purchases", "sitting",
        "sittingdown", "takingphoto", "waiting", "walkingdog",
        "walkingtogether"
    ]

    config.motion.h36m_target_length = config.motion.h36m_target_length_eval

    test_loader = {}
    for action in ACTIONS:
        dataset = H36MEval(opt=opt, split=2, actions=action)
        test_loader[action] = DataLoader(
            dataset,
            batch_size=opt.test_batch_size,
            shuffle=False,
            num_workers=0,
            pin_memory=True
        )
    # dataset = H36MEval(config, 'test') # 为什么只有一个test
    # shuffle = False
    # sampler = None
    # train_sampler = None
    # dataloader = DataLoader(dataset, batch_size=128,
    #                         num_workers=0, drop_last=False,
    #                         sampler=sampler, shuffle=shuffle, pin_memory=True)
    for action in test_loader.keys():
        print(test(config, model, test_loader[action])) #todo 修改内部

