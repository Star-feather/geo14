import argparse
import os, sys
import json
import math
import numpy as np
import copy

from model2.config import config
from model2.model import siMLPe as Model
# from datasets.h36m import H36MDataset
from utils.h36motion3d import Datasets as H36MDataset
from model2.utils.logger import get_logger, print_and_log_info
from model2.utils.pyt_utils import link_file, ensure_dir
# from datasets.h36m_eval import H36MEval
from utils.opt import Options
from model2.test import test

import torch
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

# parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)


# args = parser.parse_args()

# opt = Options().parse()

# torch.use_deterministic_algorithms(True)
# acc_log = open('baseline.txt', 'a')
# torch.manual_seed(opt.seed)
writer = SummaryWriter()

# config.motion_fc_in.temporal_fc = opt.temporal_only
# config.motion_fc_out.temporal_fc = opt.temporal_only
# config.motion_mlp.norm_axis = opt.layer_norm_axis
# config.motion_mlp.spatial_fc_only = opt.spatial_fc
# config.motion_mlp.with_normalization = opt.with_normalization
# config.motion_mlp.num_layers = opt.num

# acc_log.write(''.join('Seed : ' + str(opt.seed) + '\n'))

def get_dct_matrix(N):
    dct_m = np.eye(N)
    for k in np.arange(N):
        for i in np.arange(N):
            w = np.sqrt(2 / N)
            if k == 0:
                w = np.sqrt(1 / N)
            dct_m[k, i] = w * np.cos(np.pi * (i + 1 / 2) * k / N)
    idct_m = np.linalg.inv(dct_m)
    return dct_m, idct_m

dct_m,idct_m = get_dct_matrix(config.motion.h36m_input_length_dct)
dct_m = torch.tensor(dct_m).float().cuda().unsqueeze(0)
idct_m = torch.tensor(idct_m).float().cuda().unsqueeze(0)

def update_lr_multistep(nb_iter, total_iter, max_lr, min_lr, optimizer) :
    if nb_iter > 30000:
        current_lr = 1e-5
    else:
        current_lr = 3e-4

    for param_group in optimizer.param_groups:
        param_group["lr"] = current_lr

    return optimizer, current_lr

def gen_velocity(m):
    dm = m[:, 1:] - m[:, :-1]
    return dm

def train_step(pbar, model, optimizer, nb_iter, total_iter, max_lr, min_lr) :
    loss_mean = 0
    for (h36m_motion_train_input,h36m_motion_train_target) in pbar:
        if config.deriv_input:
            b,n,c = h36m_motion_train_input.shape
            h36m_motion_input_ = h36m_motion_train_input.clone()
            h36m_motion_input_ = torch.matmul(dct_m[:, :, :config.motion.h36m_input_length], h36m_motion_input_.cuda())
        else:
            h36m_motion_input_ = h36m_motion_train_input.clone()

        motion_pred = model(h36m_motion_input_.cuda())
        motion_pred = torch.matmul(idct_m[:, :config.motion.h36m_input_length, :], motion_pred)

        if config.deriv_output:
            offset = h36m_motion_train_input[:, -1:].cuda()
            motion_pred = motion_pred[:, :config.motion.h36m_target_length_train] + offset
        else:
            motion_pred = motion_pred[:, :config.motion.h36m_target_length_train]

        b,n,c = h36m_motion_train_target.shape
        # print(h36m_motion_train_target.shape)
        # print(motion_pred.shape)
        motion_pred = motion_pred.reshape(b,n,22,3).reshape(-1,3)
        h36m_motion_train_target = h36m_motion_train_target.cuda().reshape(b,n,22,3).reshape(-1,3)
        loss = torch.mean(torch.norm(motion_pred - h36m_motion_train_target, 2, 1))
        loss_mean += loss
        if config.use_relative_loss:
            motion_pred = motion_pred.reshape(b,n,22,3)
            dmotion_pred = gen_velocity(motion_pred)
            motion_gt = h36m_motion_train_target.reshape(b,n,22,3)
            dmotion_gt = gen_velocity(motion_gt)
            dloss = torch.mean(torch.norm((dmotion_pred - dmotion_gt).reshape(-1,3), 2, 1))
            loss = loss + dloss
        else:
            loss = loss.mean()

        writer.add_scalar('Loss/angle', loss.detach().cpu().numpy(), nb_iter)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        optimizer, current_lr = update_lr_multistep(nb_iter, total_iter, max_lr, min_lr, optimizer)
        writer.add_scalar('LR/train', current_lr, nb_iter)

    return loss_mean/800, optimizer, current_lr

def train_one(h36m_motion_train_input, model,config):
    b, n, c = h36m_motion_train_input.shape
    idx = list(range(n)) + [n - 1] * (config.motion.h36m_input_length - n)
    h36m_motion_train_input = h36m_motion_train_input[:, idx].clone() # (b,h36m_input_length,c)
    if config.deriv_input:
        b, n, c = h36m_motion_train_input.shape
        h36m_motion_input_ = h36m_motion_train_input.clone()
        h36m_motion_input_ = torch.matmul(dct_m[:, :, :config.motion.h36m_input_length], h36m_motion_input_.cuda())
    else:
        h36m_motion_input_ = h36m_motion_train_input.clone()

    motion_pred = model(h36m_motion_input_.cuda())
    motion_pred = torch.matmul(idct_m[:, :config.motion.h36m_input_length, :], motion_pred)

    if config.deriv_output:
        offset = h36m_motion_train_input[:, -1:].cuda()
        motion_pred[:, :n] += h36m_motion_train_input[:, :n].clone()
        motion_pred[:, n:config.motion.h36m_target_length_train] += offset
        
    else:
        motion_pred = motion_pred[:, :config.motion.h36m_target_length_train]

    # b, n, c = h36m_motion_train_target.shape
    #
    # motion_pred = motion_pred.reshape(b, n, 22, 3).reshape(-1, 3)
    # h36m_motion_train_target = h36m_motion_train_target.cuda().reshape(b, n, 22, 3).reshape(-1, 3)
    # loss = torch.mean(torch.norm(motion_pred - h36m_motion_train_target, 2, 1))
    # if config.use_relative_loss:
    #     motion_pred = motion_pred.reshape(b, n, 22, 3)
    #     dmotion_pred = gen_velocity(motion_pred)
    #     motion_gt = h36m_motion_train_target.reshape(b, n, 22, 3)
    #     dmotion_gt = gen_velocity(motion_gt)
    #     dloss = torch.mean(torch.norm((dmotion_pred - dmotion_gt).reshape(-1, 3), 2, 1))
    #     loss = loss + dloss
    # else:
    #     loss = loss.mean()
    # motion_pred = torch.cat([h36m_motion_train_input,motion_pred],dim=1)
    return motion_pred
# model = Model(config)
# model.train()
# model.cuda()
#
# config.motion.h36m_target_length = config.motion.h36m_target_length_train
# train_dataset = H36MDataset(opt,split=0)
# print(f'>>> 训练集长度: {len(train_dataset)}')
# train_dataloader = DataLoader(
#     train_dataset,
#     batch_size=opt.batch_size,
#     shuffle=True,
#     num_workers=0,
#     drop_last=True,
#     pin_memory=True
# )
# shuffle = True
# sampler = None
# dataloader = DataLoader(dataset, batch_size=config.batch_size,
#                         num_workers=config.num_workers, drop_last=True,
#                         sampler=sampler, shuffle=shuffle, pin_memory=True)

# eval_config = copy.deepcopy(config)
# eval_config.motion.h36m_target_length = eval_config.motion.h36m_target_length_eval
# # eval_dataset = H36MEval(eval_config, 'test')
# eval_dataset = H36MDataset(opt,split=2)
# print(f'>>> 验证集长度: {len(eval_dataset)}')
# eval_dataloader = DataLoader(
#     eval_dataset,
#     batch_size=opt.batch_size,
#     shuffle=True,
#     num_workers=0,
#     drop_last=True,
#     pin_memory=True
# )
# shuffle = False
# sampler = None
# eval_dataloader = DataLoader(eval_dataset, batch_size=128,
#                         num_workers=0, drop_last=False,
#                         sampler=sampler, shuffle=shuffle, pin_memory=True)



# initialize optimizer
# optimizer = torch.optim.Adam(model.parameters(),
#                              lr=config.cos_lr_max,
#                              weight_decay=config.weight_decay)
#
# ensure_dir(config.snapshot_dir)
# logger = get_logger(config.log_file, 'train')
# # The log shortcut uses ln -s, which is unavailable on native Windows.
# if os.name != 'nt':
#     link_file(config.log_file, config.link_log_file)
#
# print_and_log_info(logger, json.dumps(config, indent=4, sort_keys=True))
#
# if config.model_pth is not None :
#     state_dict = torch.load(config.model_pth, map_location='cpu', weights_only=True)
#     # Support the module names used in the released H36M checkpoints.
#     state_dict = {
#         key.replace('motion_transformer.transformer.', 'motion_mlp.mlps.'): value
#         for key, value in state_dict.items()
#     }
#     model.load_state_dict(state_dict, strict=True)
#     print_and_log_info(logger, "Loading model path from {} ".format(config.model_pth))
#
# ##### ------ training ------- #####
# nb_iter = 0
# avg_loss = 0.
# avg_lr = 0.
# n = 0
# joint_used_xyz = np.array([2,3,4,5,7,8,9,10,12,13,14,15,17,18,19,21,22,25,26,27,29,30]).astype(np.int64)
# while (nb_iter + 1) < config.cos_lr_total_iters:
#
#     # for (h36m_motion_input, h36m_motion_target) in dataloader:
#     for i, (p3d_h36) in enumerate(train_dataloader):
#         batch_size, seq_n, all_dim = p3d_h36.shape
#
#         if batch_size == 1:
#             continue
#         n += batch_size
#         p3d_h36 = p3d_h36.float().to(opt.cuda_idx).reshape(batch_size,seq_n,all_dim//3,-1)
#         h36m_motion_input = p3d_h36[:, :opt.input_n,joint_used_xyz].clone().reshape(batch_size,opt.input_n,-1)
#         h36m_motion_target =  p3d_h36[:, opt.input_n:opt.input_n + opt.output_n, joint_used_xyz].clone().reshape(batch_size,opt.output_n,-1)
#
#         loss, optimizer, current_lr = train_step(h36m_motion_input, h36m_motion_target, model, optimizer, nb_iter, config.cos_lr_total_iters, config.cos_lr_max, config.cos_lr_min)
#         avg_loss += loss
#         avg_lr += current_lr
#
#         if (nb_iter + 1) % config.print_every ==  0 :
#             avg_loss = avg_loss / config.print_every
#             avg_lr = avg_lr / config.print_every
#
#             print_and_log_info(logger, "Iter {} Summary: ".format(nb_iter + 1))
#             print_and_log_info(logger, f"\t lr: {avg_lr} \t Training loss: {avg_loss}")
#             avg_loss = 0
#             avg_lr = 0
#
#         if (nb_iter + 1) % config.save_every ==  0 :
#             torch.save(model.state_dict(), config.snapshot_dir + '/model-iter-' + str(nb_iter + 1) + '.pth')
#             model.eval()
#             pbar = []
#             for i,test_data in enumerate(eval_dataloader):
#                 pbar.append((test_data[:, :opt.input_n].clone().reshape(batch_size, opt.input_n, 32, -1),
#                          test_data[:, opt.input_n:opt.input_n + config.motion.h36m_target_length_eval].clone().reshape(batch_size, config.motion.h36m_target_length_eval, 32, -1)))
#
#             acc_tmp = test(eval_config, model,pbar)
#             print(acc_tmp)
#             acc_log.write(''.join(str(nb_iter + 1) + '\n'))
#             line = ''
#             for ii in acc_tmp:
#                 line += str(ii) + ' '
#             line += '\n'
#             acc_log.write(''.join(line))
#             model.train()
#
#         if (nb_iter + 1) == config.cos_lr_total_iters :
#             break
#         nb_iter += 1
#
# writer.close()
