"""Reproduce future-target dependency without training or changing checkpoints."""
import json
import inspect
import textwrap
from types import MethodType
import model.model_h36m as model_module
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch
from model.model_h36m import MultiStageModel_4


def main():
    torch.manual_seed(334)
    torch.set_num_threads(4)
    opt = SimpleNamespace(kernel_size=10, d_model=16, dct_n=35,
                          in_features=66, num_stage=12, input_n=10, output_n=25,
                          n_tcnn_layers=4, tcnn_kernel_size=[3, 3],
                          tcnn_dropout=0., drop_out=.3, cuda_idx='cuda:0',
                          )
    model = MultiStageModel_4(opt).cuda().eval()
    checkpoint = next(Path('checkpoint').glob('*/ckpt_best.pth.tar'))
    model.load_state_dict(torch.load(checkpoint, map_location='cpu', weights_only=False)['state_dict1'])
    x = torch.randn(2, 35, 66, device='cuda')
    changed = x.clone()
    changed[:, 10:] += 10
    report = {'checkpoint': str(checkpoint), 'history_frames': 10, 'future_frames': 25}
    with torch.no_grad():
        report['legacy_future_perturbation_max_delta'] = (model(x)-model(changed)).abs().max().item()
        try:
            report['legacy_history_only_output_shape'] = list(model(x[:, :10]).shape)
        except RuntimeError as error:
            report['legacy_history_only_error'] = str(error)
        # Only this audit process substitutes a history-only expression.
        # Production model source and its default leaking computation stay unchanged.
        forward_source = textwrap.dedent(inspect.getsource(MultiStageModel_4.forward))
        forward_source = forward_source.replace(
            'gt.reshape(bs,-1,self.node_n,dct_n)',
            'input_gcn1.reshape(bs, self.dct_n, self.node_n, 3).permute(0, 3, 2, 1)')
        namespace = dict(model_module.__dict__)
        exec(compile(forward_source, '<audit-only-history-context>', 'exec'), namespace)
        model.forward = MethodType(namespace['forward'], model)
        safe = model(x)
        report['fixed_future_perturbation_max_delta'] = (safe-model(changed)).abs().max().item()
        report['fixed_history_only_max_delta'] = (safe-model(x[:, :10])).abs().max().item()
    # Map every element actually used by the legacy context windows to original time.
    source_time = torch.arange(35).reshape(35, 1).expand(35, 66).reshape(3, 22, 35)
    used = torch.cat([source_time[:, :, end-4:end].flatten() for end in range(7, 11)])
    report['legacy_context_source_frames_zero_based'] = sorted(used.unique().tolist())
    report['legacy_context_future_elements'] = int((used >= 10).sum())
    report['legacy_context_total_elements'] = used.numel()
    assert report['legacy_future_perturbation_max_delta'] > 0
    assert report['fixed_future_perturbation_max_delta'] == 0
    assert report['fixed_history_only_max_delta'] == 0
    Path('audit').mkdir(exist_ok=True)
    Path('audit/leakage_check.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
