import numpy as np
import matplotlib.pyplot as plt
import time
from math import pow
# from utils import h36motion3d as datasets
from utils.opt import Options
from torch.utils.data import DataLoader
from utils import global_var
import torch
from utils.view import view_gujia
"""
目的：完成数据预处理操作，输入骨架位置信息，输出另外一种表征方式的骨架信息
参数：骨架初始信息(bs,T,66+3*3) #1,6,11
输出：另一种骨架表征信息（不包含不动点）(bs,T,24*3)
注意:
    还原数据需要使用同一个对象：保证中间不动点相同
方法：
    1.计算叉乘的方法
    2.计算输出每一帧的骨架信息(bs,T,66+2*3) -> (bs,T,n*3)
    3.还原每一帧的骨架信息  (bs,T,n*3) -> (bs,T,66+2*3)
"""
class GEOMETRIC:
    def __init__(self,leg_right,leg_left,opt,fix):
        #h36m
        # [0, 0, 1, 2, 3, 4, 0, 6, 7, 8, 9, 0, 11, 12, 13, 14, 13, 16, 17, 18, 18, 13, 21, 22, 23, 23]
        # 2 3 4 5 7 8 9 10 12 13 14 15 17 18 19 21 22 25 26 27 29 30
        self.device = opt.cuda_idx
        self.parents_h36 = torch.tensor(
            [-3,0,1,2, -2, 4, 5, 6, -4, 8, 9, 10, 9, 12, 13, 14, 14, 9, 17, 18, 19, 19],
            dtype=torch.long).to(self.device)
        #cmu
        #[-1,0,1,2,-2,4, 5, 6, -3,8 ,9, 10,11,9,13,14,15,16,15,9,19,20,21,22,21]
        # 3  4 5 6  9 10 11 12 14 15 17 18 19 21 22 23 25 26 28 30 31 32 34 35 37 left(8),right(2),(2/8)
        self.parents_cmu = torch.tensor(
            [-3,0,1,2,-2,4, 5, 6, -1,8 ,9, 10,11,9,13,14,15,16,15,9,19,20,21,22,21] ,
            dtype=torch.long).to(self.device)
        # 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23
        # -1,-1,-1,0,,1,2,3,4,5,6,7,8,8,8,11,12,13,15,16,17,18,19,20
        self.parents_3dpw = torch.tensor(
            [-1,-1,-1,0,1,2,3,4,5,6,7,8,8,8,11,12,13,15,16,17,18,19,20] ,
            dtype=torch.long).to(self.device)
        #这些属性都是在compute过程中完成计算的
        # 原点
        self.root = None
        self.bones = None
        self.fix_vectors = fix
        
        #self.fix_vectors = torch.tensor([0., 0.1, 0.],device=self.device).view(1, 1, 1, 3).expand(opt.batch_size, opt.dct_n, 22, 3).clone()
        # self.fix_vectors[:, :, [2, 3, 6, 7], :] = torch.tensor([0.1, 0., 0.],device=self.device)
        # self.fix_vectors[:, :, [12, 13,14,15,16,18,19,20,21], :] = torch.tensor([0., 0., 0.1],device=self.device)
        
        self.leg_left = leg_left
        self.leg_right = leg_right
        self.frame1 = None
        self.refer = None


    def encode(self,input_data,data_class='h36m'):
        #输入(bs,seq,66)
        bs, seq, dim = input_data.shape
        node = dim // 3
        self.root = torch.zeros((bs,seq,1,3),device=self.device)
        # (bs, seq, 22, 3)
        input_data = input_data.reshape(bs, seq,node, 3)
        #22个关节的父节点都在这里
        values = torch.tensor([[[0, 0.1, 0]]]).repeat(bs, seq, 1, 1).float().to(self.device)
        mixed_tensor = values.expand(-1, -1, -1, 3)  # (bs,seq,1,3)
        input_data_parents = torch.cat((input_data, mixed_tensor[:bs, :seq,:,:]), dim=2)  # cmu将不会使用这个索引，为了h36m也能使用，所以仍进行堆叠
        if self.leg_right is not None:
            # print(input_data_parents.shape)
            # print(self.leg_left.shape)
            input_data_parents = torch.cat((input_data_parents, self.leg_right), dim=2) #self.num1 (32,35,1,3)
        if self.leg_left is not None:
            input_data_parents = torch.cat((input_data_parents, self.leg_left), dim=2)
        input_data_parents = torch.cat((input_data_parents, self.root), dim=2) #原点放在最后，cmu要用上
        fix_vectors_expand = self.fix_vectors[:,-1:].repeat(1,seq,1,1).clone()
        # 向量化 -- 根据父节点
        parents = None
        if data_class == 'h36m':
            parents = self.parents_h36
        elif data_class == 'cmu':
            parents = self.parents_cmu
        elif data_class == '3dpw':
            parents = self.parents_3dpw
        parents_data = input_data_parents[:, :, parents]
        output_t = input_data - parents_data
        # self.old = input_data - parents_data
        self.frame1 = output_t[:, 0, :, :]  # 取第一帧 (bs, 22, 3)
        # 每个位置的长度
        # LEAK-02: full-sequence encode caches future bone lengths for decode.
        self.bones = torch.norm(output_t, dim=-1)  # (bs, seq, 22)
        # 向量与固定向量做点乘，反应正负号
        # LEAK-03: future true signs select reconstruction branches in decode.
        self.refer = torch.sum(fix_vectors_expand[:bs, :seq,:,:] * output_t, dim=-1) #(bs,seq,22)
        # 向量叉乘
        output_t = torch.cross(fix_vectors_expand[:bs, :seq,:,:], output_t)
        output_t = output_t.reshape(bs, seq, dim)
        # 输出 (bs, seq, 66) 向量信息
        return output_t


    def decode(self,input_data,data_class='h36m'):
        # 输入 (bs, seq, 66) - 向量信息
        bs, seq, dim = input_data.shape
        parents = None
        if data_class == 'h36m':
            parents = self.parents_h36
        elif data_class == 'cmu':
            parents = self.parents_cmu
        elif data_class == '3dpw':
            parents = self.parents_3dpw
        node = dim // 3
        input_data = input_data.reshape(bs, seq, node, 3)   #(bs,35,22,3)
        fix_vectors_expand = self.fix_vectors[:,-1:].repeat(1,seq,1,1).clone()
        u = (-1* torch.cross(fix_vectors_expand[:bs, :seq,:,:],input_data))/((torch.norm(fix_vectors_expand[:bs, :seq,:,:],dim=-1).unsqueeze(-1).expand(-1, -1, node, -1))**2)#(bs,seq,22,3)
        # print((torch.norm(u,dim=-1)**2)[0,0,:])
        # print((self.bones**2)[0,0,:])
        # print('u:',u[0,0])
        lamda = (abs(self.bones[:bs, :seq]**2-torch.norm(u,dim=-1)**2)/(torch.norm(fix_vectors_expand[:bs, :seq,:,:], dim=-1)**2))**(1/2)

        b1 = u + (lamda.unsqueeze(-1)) * fix_vectors_expand[:bs, :seq,:,:] # (bs,seq,22,3) + (bs,seq,22,1)*(bs,seq,22,3) -> (bs,seq,22,3)
        b2 = u - (lamda.unsqueeze(-1)) * fix_vectors_expand[:bs, :seq,:,:] # (bs,seq,22,3) + (bs,seq,22,1)*(bs,seq,22,3) -> (bs,seq,22,3)

        # print("b1:", b1[0,0,:,:])
        # print("b2:", b2[0,0,:,:])
        dot_product1 = torch.sum(b1 * fix_vectors_expand[:bs, :seq,:,:] , dim=-1)
        dot_product2 = torch.sum(b2 * fix_vectors_expand[:bs, :seq,:,:] , dim=-1)

        sign_matrix1 = torch.sign(dot_product1)
        sign_matrix2 = torch.sign(dot_product2)
        # Oracle-assisted branch selection; not available from history-only input.
        sign_reference = torch.sign(self.refer[:bs, :seq])

        # print("sign_matrix1:",sign_matrix1)
        # print("sign_matrix2:",sign_matrix2)

        # 比较符号
        same_sign1 = (sign_matrix1 == sign_reference).unsqueeze(-1).expand(-1, -1, -1, 3)
        same_sign2 = (sign_matrix2 == sign_reference).unsqueeze(-1).expand(-1, -1, -1, 3)

        # 处理全零情况
        zero_mask = ((sign_matrix1 == 0) & (sign_matrix2 == 0)).unsqueeze(-1).expand(-1, -1, -1, 3)

        # 初始化结果矩阵
        result_matrix = torch.zeros_like(b1)

        # 选择信息
        result_matrix[same_sign1] = b1[same_sign1]
        result_matrix[same_sign2] = b2[same_sign2]

        # 处理全零情况，任意选择一个
        result_matrix[zero_mask] = b1[zero_mask]
        # 数据复原
        output_current = self.build_framework(data_class,node,bs,seq,dim,result_matrix)
        return output_current,u,b1,b2,same_sign1

    def build_framework(self,data_class,node,bs,seq,dim,result_matrix):
        parents = None
        if data_class == 'h36m':
            parents = self.parents_h36
        elif data_class == 'cmu':
            parents = self.parents_cmu
        elif data_class == '3dpw':
            parents = self.parents_3dpw
        output_current = torch.zeros((bs,seq,node,3),device=self.device)
        if data_class == 'cmu' or data_class == 'h36m':
            for i in range(node):
                # print(output_current[0,0,:,:])
                if i == 0:
                    output_current[:, :, i, :] = result_matrix[:, :, i, :] + self.leg_right[:,:seq].squeeze(2)
                elif i == 4:
                    output_current[:, :, i, :] = result_matrix[:, :, i, :] + self.leg_left[:,:seq].squeeze(2)
                elif i == 8:
                    if data_class == 'h36m':
                        values = torch.tensor([[[0, 0.1, 0]]]).repeat(bs, seq, 1, 1).float().to(self.device)
                        mixed_tensor = values.expand(-1, -1, -1, 3)  # (bs,seq,1,3)
                        output_current[:, :, i, :] = result_matrix[:, :, i, :] + mixed_tensor[:bs, :, 0]
                    elif data_class == 'cmu':
                        output_current[:, :, i, :] = result_matrix[:, :, i, :] + self.root[:,:seq].squeeze(2)
                else:
                    output_current[:, :, i, :] = result_matrix[:, :, i, :] + output_current[:, :, parents[i], :]
            output_current = output_current.reshape(bs, seq, dim)
        elif data_class == '3dpw':
            for i in range(node):
                if i == 0:
                    output_current[:, :, i, :] = result_matrix[:, :, i, :] + self.root[:,:seq].squeeze(2)
                else:
                    output_current[:, :, i, :] = result_matrix[:, :, i, :] + output_current[:, :, parents[i], :]
            output_current = output_current.reshape(bs, seq, dim)
        return output_current

"""        
    show_3d用于关节可视化
    输入： [frames,node,3]
"""
def show_3d(data):
    # 可视化关节点
    # 打印每个关节每一帧的状态
    ks,node,_ = data.shape
    for i in range(node):
        print(f"第{i}个关节")
        for t in range(ks):
            print(data[t, i, :])
    # 第一帧的位置信息
    xyz = data[0, :, :]
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    for j, (x, y, z) in enumerate(xyz):
        # 每个坐标的位置
        ax.scatter(xyz[j, 0], xyz[j, 1], xyz[j, 2], c='r', s=40)
        print("第" + str(j) + "个关节的坐标")
        print(xyz[j][0], xyz[j][1], xyz[j][2])
        ax.text(x, y, z, s=f'{j}', color='blue', fontsize=12)
    for j in range(1, node):
        pa = torch.tensor(
            [-3,0,1,2, -2, 4, 5, 6, -1, 8, 9, 10, 9, 12, 13, 14, 14, 9, 17, 18, 19, 19],
            dtype=torch.long).to('cuda:0')
        ax.plot([xyz[pa, 0], xyz[j, 0]],
                [xyz[pa, 1], xyz[j, 1]],
                [xyz[pa, 2], xyz[j, 2]], 'b')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('Single-frame skeleton')
    plt.show()



# ----------------- 测试 -----------------
# if __name__ == '__main__':
#     # 用于测试的数据集
#     option = Options().parse()
#     global_var._init()
#     # 初始化变量
#     # 定义对称关节和需要忽略的关节
#     JOINT_TO_IGNORE = np.array([16, 20, 29, 24, 27, 33, 36])
#     JOINT_EQUAL = np.array([15, 15, 15, 23, 23, 32, 32])
#     torch.set_printoptions(precision=10, threshold=torch.inf, linewidth=120, sci_mode=False)
#
#     # dim_used = np.array([
#     #     6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 21, 22, 23, 24, 25,
#     #     26, 27, 28, 29, 30, 31, 32, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
#     #     46, 47, 51, 52, 53, 54, 55, 56, 57, 58, 59, 63, 64, 65, 66, 67, 68,
#     #     75, 76, 77, 78, 79, 80, 81, 82, 83, 87, 88, 89, 90, 91, 92
#     # ])  # 输入(bs,T,66)
#     #
#     # JOINT_TO_IGNORE = np.array([16, 20, 23, 24, 28, 31])
#     # INDEX_TO_IGNORE = np.concatenate((
#     #     JOINT_TO_IGNORE * 3,
#     #     JOINT_TO_IGNORE * 3 + 1,
#     #     JOINT_TO_IGNORE * 3 + 2
#     # ))
#     # torch.set_printoptions(precision=10, threshold=torch.inf, linewidth=120, sci_mode=False)
#     VIEW_JOINT_USED = np.array([
#         0,2,3,4,5,6,  8,9,10,11,12 , 14,15,17,18,19  ,21,22,23,25,26,28, 30,31,32,34,35,37
#     ])
#     VIEW_USED = np.concatenate((
#         VIEW_JOINT_USED * 3,
#         VIEW_JOINT_USED * 3 + 1,
#         VIEW_JOINT_USED * 3 + 2
#     ))
#     n = 0
#     in_n = option.input_n
#     out_n = option.output_n
#     seq_in = option.kernel_size
#     start_time = time.time()
#     # 计算对称关节索引
#     index_to_ignore = np.concatenate((JOINT_TO_IGNORE * 3, JOINT_TO_IGNORE * 3 + 1, JOINT_TO_IGNORE * 3 + 2))
#     index_to_equal = np.concatenate((JOINT_EQUAL * 3, JOINT_EQUAL * 3 + 1, JOINT_EQUAL * 3 + 2))
#     train_dataset = CMU_Motion3D(option, split=0)
#     data_loader = DataLoader(
#         train_dataset,
#         batch_size=option.batch_size,
#         shuffle=True,
#         num_workers=0,
#         pin_memory=True
#     )
#     count = 0
#     is_train = 0
#     # 遍历数据加载器
#     for x, (p3d_cmu) in enumerate(data_loader):
#         # print(i)
#         batch_size, seq_n, all_dim = p3d_cmu.shape
#         # 跳过单样本批次（训练时）
#         if batch_size == 1 and is_train == 0:
#             continue
#         n += batch_size
#         batch_time = time.time()
#         p3d_cmu = p3d_cmu.float().to(option.cuda_idx)
#         p3d_cmu_out = p3d_cmu.clone()
#
#         # 获取使用的维度
#         dim_used = data_loader.dataset.dim_used
#
#         # 准备输入数据
#         input_data = p3d_cmu[:, :, dim_used].clone()
#         # 用于可视化部分
#
#         # p3d_h36_t = p3d_cmu[:, :, dim_used].clone()  # (bs,seq,78)
#         # num11 = p3d_cmu[:, :, [33, 34, 35]].unsqueeze(2)
#         # num1 = p3d_cmu[:, :, [3, 4, 5]].unsqueeze(2)
#         # num6 = p3d_cmu[:, :, [18, 19, 20]].unsqueeze(2)
#
#         # 数据预处理器
#         node2 = p3d_cmu[:, :, [6, 7, 8]].unsqueeze(2)
#         # print(leg_right)
#         node8 = p3d_cmu[:, :, [24, 25, 26]].unsqueeze(2)
#         # print(leg_left)
#         values = torch.tensor([[[0, 0.1, 0]]]).repeat(batch_size, seq_n, 1, 1).float().to(option.cuda_idx)
#         mixed_tensor = values.expand(-1, -1, -1, 3)
#         # print(mixed_tensor)
#         geo = GEOMETRIC(leg_right=node2, leg_left=node8, fix=mixed_tensor)
#
#         input_data_geo = geo.encode(input_data, data_class='cmu') #
#         output = geo.decode(input_data_geo,data_class='cmu') #
#         p3d_cmu_out[:,:,dim_used] = output
#         p3d_cmu_out[:,:,JOINT_TO_IGNORE] = p3d_cmu_out[:,:,JOINT_EQUAL]
#
#         bs, frame, _ = p3d_cmu.shape
#         input_data_cpu = p3d_cmu[:,:,VIEW_USED].detach().cpu().numpy()[0].reshape(frame, -1, 3)
#         p3d_cmu_out_cpu = p3d_cmu_out[:,:,VIEW_USED].detach().cpu().numpy()[0].reshape(frame, -1, 3)
#         view_gujia(input_data_cpu, p3d_cmu_out_cpu,data_class='cmu')
#         p3d_sup = p3d_cmu.clone()[:, :, dim_used][:, -out_n - seq_in:]
#         p3d_sup_geo = geo.encode(p3d_sup, data_class='cmu') #


