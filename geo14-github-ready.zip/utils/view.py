import matplotlib.pyplot as plt
import matplotlib.transforms as transforms
import numpy as np

# 假设我们有以下数据
# template_positions 是形状为 (num_frames, num_joints, 3) 的数组，表示模板小人的关节点坐标序列
# predicted_positions 是形状为 (num_frames, num_joints, 3) 的数组，表示预测小人的关节点坐标序列

# num_frames = 25  # 帧数
# num_joints = 17  # 关节点数
#
# # 为了示例，我们创建一些随机数据作为模板小人和预测小人的坐标序列
# template_positions = np.random.rand(num_frames, num_joints,3) * 100
# predicted_positions = np.random.rand(num_frames, num_joints, 3) * 100
                #   0,1,2,3,4,5, 6, 7, 8, 9,10,11,12,13,14,15,16
#可视化需要使用的关节： 0,1,3,5,6,8,10,12,13,14,15,17,18,19,25,26,27
# 定义关节点之间的连接顺序
joint_connections_h36 = [
    (0, 1), (1, 2), (2, 3),  # 左腿
    (0, 4), (4, 5), (5, 6),  # 右腿
    (0, 7), (7, 8),          # 躯干
    (8, 9), (9,10),          # 头部
    (8,11),(11,12),(12,13),  # 左臂
    (8,14),(14,15),(15,16)   # 右臂
]
#cmu可视化需要使用的关节：0,2,3,4,5,6,  8,9,10,11,12 , 14,15,17,18,19  ,21,22,23,25,26,28  30,31,32,34,35,37
                               #5             10   11 12       15                  21  22
joint_connections_cmu = [
    (0, 1), (1, 2), (2, 3),(3,4),(4,5),  # 右腿
    (0, 6), (6, 7), (7, 8),(8,9),(9,10),  # 右腿
    (0, 11), (11, 12),(12,13),(13,14),(14,15),# 躯干 + 头部
    (12,16),(16,17),(17,18),(18,19),(19,20),(18,21),  # 左臂
    (12,22),(22,23),(23,24),(24,25),(25,26),(24,27),   # 右臂
]
#3dpw可视化需要使用的关节：0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23
joint_connections_3dpw = [
    (0,1),(1,4),(4,7),(7,10),
    (0,2),(2,5),(5,8),(8,11),
    (0,3),(3,6),(6,9),(9,12),(12,15),
    (9,13),(13,16),(16,18),(18,20),(20,22),
    (9,14),(14,17),(17,19),(19,21),(21,23)
]

def view_gujia(template_positions,predicted_positions,name,data_class='h36m'):
    # print(template_positions.shape)
    joint_connections = None
    if data_class == 'h36m':
        joint_connections = joint_connections_h36
    elif data_class == 'cmu':
        joint_connections = joint_connections_cmu
    elif data_class == '3dpw':
        joint_connections = joint_connections_3dpw
    # template_positions = template_positions.transpose((1, 0, 2))
    # predicted_positions = predicted_positions.transpose((1, 0, 2))
    frames, dim, _ = predicted_positions.shape
    # 创建图形和子图
    fig, axs = plt.subplots(1, frames, figsize=(60, 4))
    # for joint_idx in range(template_positions.shape[1]):
    #     # 提取该关节点的所有帧的坐标
    #     joint_positions = template_positions[:, joint_idx, :]
    #     # 打印关节点的坐标
    #     print(f"第 {joint_idx} 个关节的坐标：")
    #     for frame_idx in range(joint_positions.shape[0]):
    #         print(
    #             f"帧 {frame_idx}：X={joint_positions[frame_idx, 0]:.2f}, Y={joint_positions[frame_idx, 1]:.2f}, Z={joint_positions[frame_idx, 2]:.2f}")

    # 遍历每一帧并绘制小人
    for frame_idx, ax in enumerate(axs):
        # 获取当前帧的模板小人和预测小人的关节点坐标
        template_joint_positions = template_positions[frame_idx]
        predicted_joint_positions = predicted_positions[frame_idx]

        rotation_angle = 165  # 顺时针旋转45度
        rotation_matrix = np.array([
            [np.cos(np.radians(-rotation_angle)), 0, np.sin(np.radians(-rotation_angle))],
            [0, 1, 0],
            [-np.sin(np.radians(-rotation_angle)), 0, np.cos(np.radians(-rotation_angle))]
        ])
        template_joint_positions = np.dot(template_joint_positions, rotation_matrix)
        predicted_joint_positions = np.dot(predicted_joint_positions, rotation_matrix)

        ax.plot([template_joint_positions[joint_connections[0][0], 0],
                 template_joint_positions[joint_connections[0][1], 0]],
                [template_joint_positions[joint_connections[0][0], 1],
                 template_joint_positions[joint_connections[0][1], 1]], 'k-',
                label='Template')
        for connection in joint_connections[1:]:
            ax.plot([template_joint_positions[connection[0], 0], template_joint_positions[connection[1], 0]],
                    [template_joint_positions[connection[0], 1], template_joint_positions[connection[1], 1]], 'k-')

        ax.scatter(template_joint_positions[:, 0], template_joint_positions[:, 1], c='black', s=50, label='Template')

        # 绘制预测小人
        ax.plot([predicted_joint_positions[joint_connections[0][0], 0],
                 predicted_joint_positions[joint_connections[0][1], 0]],
                [predicted_joint_positions[joint_connections[0][0], 1],
                 predicted_joint_positions[joint_connections[0][1], 1]], 'r-',
                label='Predicted')
        for connection in joint_connections[1:]:
            ax.plot([predicted_joint_positions[connection[0], 0], predicted_joint_positions[connection[1], 0]],
                    [predicted_joint_positions[connection[0], 1], predicted_joint_positions[connection[1], 1]], 'r-',)
        ax.scatter(predicted_joint_positions[:, 0], predicted_joint_positions[:, 1], c='red', s=50, label='Predicted')
        for i, pos in enumerate(template_joint_positions):
            ax.text(pos[0], pos[1], f'{i}', fontsize=10, color='blue')

        # 绘制关节点之间的连线
        # for connection in joint_connections:
        #     ax.plot([template_joint_positions[connection[0], 0], predicted_joint_positions[connection[0], 0]],
        #             [template_joint_positions[connection[0], 1], predicted_joint_positions[connection[0], 1]], c='gray')
        #     ax.plot([template_joint_positions[connection[1], 0], predicted_joint_positions[connection[1], 0]],
        #             [template_joint_positions[connection[1], 1], predicted_joint_positions[connection[1], 1]], c='gray')

        # 隐藏坐标轴
        ax.axis('off')

    # 添加图例
    axs[0].legend()

    # 调整布局
    plt.tight_layout()

    # 显示图形
    plt.savefig(f"predict{name}.png")
    plt.close(fig)
    # plt.show()
