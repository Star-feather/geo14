from torch.nn import Module
from torch import nn
import torch
import math
import utils.util as util
from siMLPe import mlp_4d
import numpy as np
from torch.nn.parameter import Parameter
from utils.opt import Options
import sys
from model import BaseModel as BaseBlock
class MultiStageModel_4(Module):
    def __init__(self, opt):
        super(MultiStageModel_4, self).__init__()

        self.opt = opt
        self.kernel_size = opt.kernel_size
        self.d_model = opt.d_model
        self.dct_n = opt.dct_n
        self.in_features = opt.in_features
        self.num_stage = opt.num_stage
        self.node_n = self.in_features // 3
        self.input_n = opt.input_n
        self.output_n = opt.output_n
        self.seq = self.input_n + self.output_n

        # 模型参数验证
        assert opt.kernel_size == 10, "Kernel size must be 10"
        
        # # 权重参数
        self.w1 = nn.Parameter(torch.tensor(0.07, requires_grad=True))
        self.w2 = nn.Parameter(torch.tensor(0.28, requires_grad=True))
        self.w3 = nn.Parameter(torch.tensor(0.65, requires_grad=True))
        self.w4 = nn.Parameter(torch.tensor(0.1, requires_grad=True))  # 特殊分支权重s

        # 编码器-解码器结构
        self.encoder_layer_num = 1
        self.decoder_layer_num = 1
        
        # 卷积层用于特征融合
        self.conv70_35 = torch.nn.Conv2d(in_channels=self.seq * 2, out_channels=self.seq, kernel_size=(1,1))
        
        self.final_proj1 = nn.Conv2d(3, self.d_model, kernel_size=1)
        self.final_proj2 = nn.Conv2d(3, self.d_model, kernel_size=1)
        self.final_proj3 = nn.Conv2d(3, self.d_model, kernel_size=1)
        self.final_proj4 = nn.Conv2d(3, self.d_model, kernel_size=1)

        # 窗口大小参数
        self.window_size = 5

        # 四个解码器分支
        dec_config = {
            'in_channal': self.d_model,
            'out_channal': self.d_model,
            'n_txcnn_layers': opt.n_tcnn_layers,
            'txc_kernel_size': opt.tcnn_kernel_size,
            'txc_dropout': opt.tcnn_dropout,
            'node_n': self.node_n,
            'seq_len': self.dct_n,
            'p_dropout': opt.drop_out,
            'num_stage': self.decoder_layer_num,
            'snum_stage': 2
        }
        self.gcn_decoder1 = BaseBlock.GCN_decoder(**dec_config)
        self.gcn_decoder2 = BaseBlock.GCN_decoder(**dec_config)
        self.gcn_decoder3 = BaseBlock.GCN_decoder(**dec_config)
        self.gcn_decoder4 = BaseBlock.GCN_decoder(**dec_config)

        
        # 动态确定需要更新的帧数
        self.num_update_frames = self.window_size - 1 if self.window_size > 1 else 1
        
        # 动态创建GCN残差模块
        self.gcn_blocks = nn.ModuleList([
            BaseBlock.GraphConvolution(
                in_c=3,
                out_c=3,
                node_n=self.node_n,
                seq_len=self.window_size,
                bias=True
            ) for _ in range(self.num_update_frames)
        ])
        self.gcn_blocks2 =BaseBlock.GraphConvolution(
                in_c=3,
                out_c=3,
                node_n=self.node_n,
                seq_len=10,
                bias=True
            )

        # MLP处理模块
        self.mlp_blockt1 = mlp_4d.MLPblock(
            dim=self.node_n, seq=self.window_size,
            use_norm=True, 
            use_spatial_fc=False,
            layernorm_axis='spatial'
        )
        self.mlp_blockt2 = mlp_4d.MLPblock(
            dim=self.node_n, seq=self.window_size,
            use_norm=True,
            use_spatial_fc=False,
            layernorm_axis='spatial'
        )
        self.mlp_blocks = mlp_4d.MLPblock(
            dim=self.node_n, seq=self.window_size,
            use_norm=True, 
            use_spatial_fc=True,
            layernorm_axis='temporal'
        )


    def forward(self, src):
        # src : (bs,35,66)
        bs = src.shape[0] # batch_size
        dct_n = src.shape[1] # 35: 10(历史) +25 (未来)
        gt = src.clone() # grand true : 10(历史) +25 (未来) 包含不合法数据 (bs,35,66)
        # 生成输入序列 idx :(0,1,2,3,4,5,6,7,8,9,9,9,9,9,9...) 共35
        idx = list(range(self.kernel_size)) + [self.kernel_size - 1] * (self.dct_n - self.kernel_size)
        input_gcn1 = src[:, idx].clone() # 合法输入
        # LEAK-01 (intentionally preserved): gt still includes future data at test time.
        # The residual gt.reshape below mixes time and coordinate axes. See README.
        # gt = src[:, idx].clone()
        # 计算归一化权重
        total_weight = self.w1 + self.w2 + self.w3 + self.w4
        w1_normalized = self.w1 / total_weight
        w2_normalized = self.w2 / total_weight
        w3_normalized = self.w3 / total_weight
        w4_normalized = self.w4 / total_weight

        # DCT变换准备
        dct_m, idct_m = util.get_dct_matrix(self.dct_n)
        dct_m = torch.from_numpy(dct_m).float().to(self.opt.cuda_idx)
        idct_m = torch.from_numpy(idct_m).float().to(self.opt.cuda_idx)

        # 输入预处理 [b,78,dct_n]->[b,3,26,dct_n]
        input_gcn_dct = torch.einsum('ij,bjk->bik', dct_m[:self.dct_n], input_gcn1)
        input_gcn_dct = input_gcn_dct.permute(0, 2, 1)
        input_gcn_dct = input_gcn_dct.reshape(bs, self.node_n, -1, self.dct_n).permute(0, 2, 1, 3) # [bs, 3, self.node_n, dct_n]

        # ================= 主处理分支 =================
        # 第一级
        # print('input_gcn_dct:', input_gcn_dct[0,:,:,0])
        latent_gcn_dct = self.final_proj1(input_gcn_dct) # [bs, 16, self.node_n, dct_n]
        # for name, param in self.mlp_final1.named_parameters():
        #     print(f"Name: {name}")
        #     print(f"Type: {type(param)}")
        #     print(f"Size: {param.size()}")
        #     print(f"Values: {param}\n")

        # latent_gcn_dct = self.mlp_final1(input_gcn_dct.reshape(bs,-1)) # [bs, 16, self.node_n, dct_n]
        # latent_gcn_dct = latent_gcn_dct.reshape(bs,16,self.node_n,dct_n)
        # print('latent_gcn_dct:',latent_gcn_dct[0,:,:,0])
        output_dct_1 = self.gcn_decoder1(latent_gcn_dct)[:, :, :, :self.dct_n]

        # 第二级
        latent_gcn_dct = self.final_proj2(output_dct_1) # [bs, 16, self.node_n, dct_n]


        # latent_gcn_dct = self.mlp_final2(output_dct_1.reshape(bs, -1))
        # latent_gcn_dct = latent_gcn_dct.reshape(bs,16,self.node_n,dct_n)
        output_dct_2 = self.gcn_decoder2(latent_gcn_dct)[:, :, :, :self.dct_n]

        # 第三级
        latent_gcn_dct = self.final_proj3(output_dct_2) # [bs, 16, self.node_n, dct_n]


        # latent_gcn_dct = self.mlp_final3(output_dct_2.reshape(bs, -1))
        # latent_gcn_dct = latent_gcn_dct.reshape(bs, 16, self.node_n, dct_n)
        output_dct_3 = self.gcn_decoder3(latent_gcn_dct)[:, :, :, :self.dct_n]

        # 第四级
        latent_gcn_dct = self.final_proj4(output_dct_3) # [bs, 16, self.node_n, dct_n]


        # latent_gcn_dct = self.mlp_final4(output_dct_3.reshape(bs, -1))
        # latent_gcn_dct = latent_gcn_dct.reshape(bs,16,self.node_n,dct_n)
        output_dct_4 = self.gcn_decoder4(latent_gcn_dct)[:, :, :, :self.dct_n]

        # # 加权融合三路输出
        com_out_fin = output_dct_1 * w1_normalized + output_dct_2 * w2_normalized + output_dct_3 * w3_normalized + output_dct_4 * w4_normalized # [bs, 3, self.node_n, dct_n]
        """
        # ================= 精确残差逐帧更新2 =================

        update_end = self.input_n
        input_frames = com_out_fin   #(bs,3,22,35)
        residual_input = com_out_fin[:, :, :, :update_end] - gt.reshape(bs, -1, self.node_n, dct_n)[:,:,:,:update_end]   #(bs,3,22,10)-(bs,3,22,10) = (bs,3,22,10)
        output_of_differ = self.gcn_blocks2(residual_input) #(bs,3,22,10)
        midoutput = self.mlp_blocks(input_frames)           #(bs,3,22,35)
        # 残差注入
        midoutput[:, :, :, :update_end] += output_of_differ #(bs,3,22,:10) + (bs,3,22,10)  = (bs,3,22,35)
        output_frame = self.mlp_blockt(midoutput)  #(bs,3,22,35)
        output_dct_fin = torch.cat((com_out_fin[:, :, :, :self.input_n],output_frame[:,:,:,self.input_n:]), dim=3)
        """
        
        
        #将idct放到逐帧更新前面
        #print(com_out_fin.shape)
        com_out_fin = torch.matmul(idct_m[:, :self.dct_n], com_out_fin.reshape(bs,3*self.node_n,self.dct_n).permute(0, 2, 1)) # [bs, dct, 66]
        com_out_fin = com_out_fin.reshape(bs, self.dct_n, 3, self.node_n).permute(0, 2, 3, 1).contiguous()  # [bs, 3, self.node_n, dct_n]

        # ================= 精确残差逐帧更新1 =================
        output_updated = {}  # 存储更新后的帧
        output_list = []     # 最终输出序列
        
        # 第一步：确定需要更新的帧范围
        # 对于N=2: 更新帧10 (索引10)
        # 对于N=3: 更新帧9-10 (索引9-10)
        # 对于N=4: 更新帧8-10 (索引8-10)
        # 对于N=5: 更新帧7-10 (索引7-10)
        update_start = self.input_n - (self.window_size - 1) + 1
        update_end = self.input_n  # 10
        update_indices = list(range(update_start, update_end + 1))
        
        # 第二步：按顺序更新这些帧（使用原始数据计算残差）
        # gt = gt.permute(0, 2, 1)
        # gt = gt.reshape(bs, self.node_n, -1, dct_n)
        # gt = gt.permute(0, 2, 1, 3)
        for idx, update_idx in enumerate(update_indices):
            # 确定上下文窗口（前window_size-1帧）
            context_start = update_idx - (self.window_size - 1)
            context_frames = list(range(context_start, update_idx))

            # 构建输入张量 [原始上下文帧 + 当前帧]
            input_frames = com_out_fin[:, :, :, context_start: update_idx + 1].clone() # [b, c, n, window_size]

            # 计算残差（仅对输入范围内的帧）
            residual_input = com_out_fin[:, :, :, context_start: update_idx] - \
                            gt.reshape(bs,-1,self.node_n,dct_n)[:, :, :, context_start: update_idx] #.reshape(bs, -1, self.node_n, dct_n)

            epsilon = 1e-9
            new_tensor = torch.full([bs,3,self.node_n,1], epsilon, dtype=residual_input.dtype, device=residual_input.device)
            residual_input = torch.cat((residual_input, new_tensor), dim=-1)

            output_of_differ = self.gcn_blocks[idx](residual_input)

            # 将误差解码
            midoutput = self.mlp_blockt1(output_of_differ)

            # 残差注入
            input_frames = input_frames + midoutput
            # Preserve the original sequential update without invalidating autograd views.
            com_out_fin = com_out_fin.clone()
            com_out_fin[:, :, :, context_start: update_idx + 1] = input_frames

            output_frame = self.mlp_blockt2(input_frames)
            #舍弃不用
            #计算残差 -> 计算cos
            # dot_product = torch.sum(com_out_fin[:, :, :, context_start: update_idx] * gt.reshape(bs, -1, self.node_n, dct_n)[:, :, :, context_start: update_idx], dim=1, keepdim=True)
            # norm_out = torch.sqrt(torch.sum((com_out_fin[:, :, :, context_start: update_idx]) ** 2, dim=1, keepdim=True))  # 形状 [bs, 1, node_n, dct_n]
            # norm_gt = torch.sqrt(torch.sum((gt.reshape(bs, -1, self.node_n, dct_n)[:, :, :, context_start: update_idx]) ** 2, dim=1, keepdim=True))
            # cos_differ = dot_product / (norm_out * norm_gt)   #[bs, node_n, dct_n]
            #
            # residual_input = input_frames.clone()
            # residual_input[:, :, :, :self.window_size - 1] = input_frames[:, :, :, :self.window_size - 1]  * cos_differ
            # # output_of_differ = self.gcn_blocks[idx](residual_input)
            # midoutput = self.mlp_blocks(residual_input)
            # # midoutput[:, :, :, :self.window_size - 1] += output_of_differ
            # output_frame = self.mlp_blockt(midoutput)
            # 只保留当前帧的更新结果
            updated_frame = output_frame[:, :, :, -1]
            output_updated[update_idx] = updated_frame
        output_list.append(output_updated[self.input_n].unsqueeze(-1))  # 添加最后更新的帧
        
        # 第三步：预测后续帧（使用更新后的帧）
        predict_start = self.input_n + 1 # 11
        predict_end = self.input_n + self.output_n - 1 # 34
        
        for predict_idx in range(predict_start, predict_end + 1):
            # 构建输入窗口 [更新后的前window_size帧]
            context_start = predict_idx - self.window_size + 1
            input_frames = []
            
            # 添加上下文帧
            for frame_idx in range(context_start, predict_idx):
                input_frames.append(output_updated[frame_idx].unsqueeze(-1))
            input_frames.append(com_out_fin[:, :, :, predict_idx].unsqueeze(-1))  # 添加当前帧
            
            input_tensor = torch.cat(input_frames, dim=-1)  # [b, c, n, window_size]
            
            # 双MLP处理
            # midoutput = self.mlp_blockt1(input_tensor)
            output_frame = self.mlp_blockt2(input_tensor)
            
            # 取最后一帧作为预测结果
            predicted_frame = output_frame[:, :, :, -1]
            output_updated[predict_idx] = predicted_frame
            output_list.append(predicted_frame.unsqueeze(-1))
        
        output_concatenated = torch.cat(output_list, dim=-1)  # [b, c, n, output_n]

        output_fin = torch.cat((
            com_out_fin[:, :, :, :self.input_n],  # 原始输入帧0-9
            output_concatenated # 更新/预测帧
        ), dim=3) # (bs,3,22,35)

        # ================= 输出处理 =================
        # 主分支输出转换
        #(bs,3,22,35) -> (bs,22,3,35) -> (bs,35,66)
        output_fin = output_fin.permute(0, 2, 1, 3).reshape(bs, self.dct_n, -1) # [bs, dct_n, 66]
        
        # 分支融合
        output_fin = torch.cat((output_fin, input_gcn1), dim=1)
        
        # 降维处理
        output_fin = self.conv70_35(output_fin.reshape(bs, self.dct_n * 2, self.node_n, -1)).reshape(bs, self.dct_n, -1)

        return output_fin
if __name__ == '__main__':
    option = Options().parse()
    option.d_model = 64
    model = MultiStageModel_4(opt=option).cuda()
    print(">>> total params: {:.2f}M".format(sum(p.numel() for p in model.parameters()) / 1000000.0))
    src = torch.randn(32, 35, 66).cuda()  # [bs, seq_len, features]
    outputs = model(src)