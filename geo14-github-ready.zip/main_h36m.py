import os
import time
import sys

import model2.model

sys.path.append('./')
import numpy as np
import torch

torch.cuda.empty_cache()
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from utils import h36motion3d as datasets
from utils import util, log, global_var
from utils.opt import Options
from model.model_h36m import MultiStageModel_4 as BARNet
from utils.geometric import GEOMETRIC
import random
from model2.config import config
from model2.test import test_one
from model2.train import train_step,train_one

# 设置环境变量解决CUDA错误
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

# 定义动作常量
ACTIONS = [
    "walking", "eating", "smoking", "discussion", "directions",
    "greeting", "phoning", "posing", "purchases", "sitting",
    "sittingdown", "takingphoto", "waiting", "walkingdog",
    "walkingtogether"
]
# 0 1 6 11 16 20 23 24 28 31  忽略的关节
# 定义使用的维度索引
DIM_USED = np.array([
    6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 21, 22, 23, 24, 25,
    26, 27, 28, 29, 30, 31, 32, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
    46, 47, 51, 52, 53, 54, 55, 56, 57, 58, 59, 63, 64, 65, 66, 67, 68,
    75, 76, 77, 78, 79, 80, 81, 82, 83, 87, 88, 89, 90, 91, 92
])  # 输入(bs,T,75)
joint_used_xyz = np.array([2, 3, 4, 5, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19, 21, 22, 25, 26, 27, 29, 30]).astype(
    np.int64)
# 定义需要忽略的关节和对应的索引
JOINT_TO_IGNORE = np.array([16, 20, 23, 24, 28, 31])
INDEX_TO_IGNORE = np.concatenate((
    JOINT_TO_IGNORE * 3,
    JOINT_TO_IGNORE * 3 + 1,
    JOINT_TO_IGNORE * 3 + 2
))

# 定义对称关节和对应的索引
JOINT_EQUAL = np.array([13, 19, 22, 13, 27, 30])
INDEX_TO_EQUAL = np.concatenate((
    JOINT_EQUAL * 3,
    JOINT_EQUAL * 3 + 1,
    JOINT_EQUAL * 3 + 2
))


def set_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def main(opt):
    """主训练函数"""
    global ACTIONS
    ACTIONS = opt.actions or ACTIONS
    lr1 = opt.lr_now
    lr2 = opt.lr_now
    start_epoch = 1
    print('>>> 创建模型')
    set_seed(334)
    net_pred1 = BARNet(opt=opt)
    net_pred1.to(opt.cuda_idx)

    # 初始化优化器


    # 第二个模型-----------
    print('>>> 创建模型')
    set_seed(334)
    net_pred2 = model2.model.siMLPe(config=config)
    net_pred2.to(opt.cuda_idx)
    optimizer2 = torch.optim.Adam(net_pred2.parameters(),
                                 lr=config.cos_lr_max,
                                 weight_decay=config.weight_decay)

    all_params = list(net_pred1.parameters()) + list(net_pred2.parameters())

    optimizer1 = optim.Adam(
        filter(lambda x: x.requires_grad, all_params),
        lr=opt.lr_now
    )

    # 第二个模型-----------

    print(f">>> 总参数量: {(sum(p.numel() for p in net_pred1.parameters()) + sum(p.numel() for p in net_pred2.parameters())) / 1e6:.2f}M")
    # print(f">>> 总参数量: {sum(p.numel() for p in all_params) / 1e6:.2f}M")
    # 加载检查点
    if opt.is_load or opt.is_eval:
        model_path = './{}/ckpt_best.pth.tar'.format(opt.ckpt) if opt.is_eval else './{}/ckpt_last.pth.tar'.format(
            opt.ckpt)
        print(f">>> 从 '{model_path}' 加载检查点")
        ckpt = torch.load(model_path, map_location=torch.device('cpu'), weights_only=False)
        start_epoch = ckpt['epoch'] + 1
        err_best = ckpt['err1']
        lr1 = ckpt['lr1']
        lr2 = ckpt['lr2']
        net_pred1.load_state_dict(ckpt['state_dict1'])
        net_pred2.load_state_dict(ckpt['state_dict2'])
        optimizer1.load_state_dict(ckpt['optimizer1'])
        optimizer2.load_state_dict(ckpt['optimizer2'])
        print(f">>> 检查点加载完成 (epoch: {ckpt['epoch']} | err: {ckpt['err1']})")

    # 加载数据集
    print('>>> 加载数据集')
    if not opt.is_eval:
        # 训练集
        train_dataset = datasets.Datasets(opt, split=0, actions=opt.actions)
        print(f'>>> 训练集长度: {len(train_dataset)}')
        train_loader = DataLoader(
            train_dataset,
            batch_size=opt.batch_size,
            shuffle=True,
            num_workers=0,
            pin_memory=True
        )

        # 验证集
        # LEAK-04: preserve original S5 validation/test overlap as requested.
        valid_dataset = datasets.Datasets(opt, split=2, actions=opt.actions)
        print(f'>>> 验证集长度: {len(valid_dataset)}')
        valid_loader = DataLoader(
            valid_dataset,
            batch_size=opt.test_batch_size,
            shuffle=True,
            num_workers=0,
            pin_memory=True
        )

    # 测试集
    test_loader = {}
    for action in ACTIONS:
        dataset = datasets.Datasets(opt=opt, split=2, actions=action)
        test_loader[action] = DataLoader(
            dataset,
            batch_size=opt.test_batch_size,
            shuffle=False,
            num_workers=0,
            pin_memory=True
        )

    # 评估模式
    if opt.is_eval:
        ret_test = run_model(net_pred1, net_pred2, is_train=3, data_loader=test_loader, opt=opt)
        ret_log = np.array([])
        head = np.array([])
        for key in ret_test.keys():
            ret_log = np.append(ret_log, [ret_test[key]])
            head = np.append(head, [key])
        log.save_csv_log(opt, head, ret_log, is_create=True, file_name='test_walking')
        return

    # 训练模式
    err_best = 1000
    for epoch in range(start_epoch, opt.epoch + 1):
        is_best = False
        lr1 = util.lr_decay_mine(optimizer1, lr1, 0.1 ** (1 / opt.epoch))
        lr2 = util.lr_decay_mine(optimizer2, lr2, 0.1 ** (1 / opt.epoch))

        print(f'>>> 训练周期: {epoch}')
        # 训练步骤
        ret_train = run_model(net_pred1, net_pred2, optimizer1, optimizer2, is_train=0, data_loader=train_loader,
                              opt=opt, epo=epoch)
        print(f'训练误差:'
              f'model1: {ret_train["model1"]["m_p3d_h36"]:.3f}  |'
              f'model2: {ret_train["model2"]["m_p3d_h36"]:.3f}')

        # 验证步骤
        ret_valid = run_model(net_pred1, net_pred2, is_train=1, data_loader=valid_loader, opt=opt, epo=epoch)
        print(f'训练误差:'
              f'model1: {ret_valid["model1"]["m_p3d_h36"]:.3f}  |'
              f'model2: {ret_valid["model2"]["m_p3d_h36"]:.3f}')

        # 测试步骤 todo 修改数据的保存方式
        eval_results = []
        avg_ret_log = []
        for action in ACTIONS:
            ret_test = run_model(net_pred1, net_pred2, is_train=3, data_loader=test_loader[action], opt=opt, epo=epoch)
            # 准备日志数据
            ret_log_eval = [action]
            head_eval = ['action']
            for key in ret_test["final"].keys():
                ret_log_eval.append(ret_test["final"][key])
                head_eval.append(f'test_{key}')

            eval_results.append(ret_log_eval)
            avg_ret_log.append(ret_log_eval[1:])

        # 计算平均误差
        avg_ret_log = np.array(avg_ret_log, dtype=np.float64).mean(axis=0)
        last_test_key = list(ret_test["final"].keys())[-1]
        print(f'测试误差: {ret_test["final"][last_test_key]:.3f}')

        # 保存日志和检查点
        need_create = True
        for model_name in ['model1', 'model2', 'final']:
            ret_log = [epoch, lr1] if model_name == "model1" else [epoch, lr2]
            head = ['epoch', 'lr']
            if model_name != "final":
                for key in ret_train[model_name].keys():
                    ret_log.append(ret_train[model_name][key])
                    head.append(f"train_{key}")
                for key in ret_valid[model_name].keys():
                    ret_log.append(ret_valid[model_name][key])
                    head.append(f'valid_{key}')
            for key in ret_test[model_name].keys():
                ret_log.append(ret_test[model_name][key])
                head.append(f'test_{key}')
            log.save_csv_log(opt, head, ret_log, is_create=((epoch == 1) and need_create))
            need_create = False

        # 更新最佳模型
        if ret_valid['model1']['m_p3d_h36'] < err_best:
            err_best = ret_valid['model1']['m_p3d_h36']
            is_best = True

            # 保存评估结果
            is_create = True
            for i, action in enumerate(ACTIONS):
                log.save_csv_eval_log(opt, head_eval, np.array(eval_results[i]), is_create=is_create)
                is_create = False

            # 保存平均结果
            write_ret_log = eval_results[0].copy()
            write_ret_log[0] = 'avg'
            write_ret_log[1:] = avg_ret_log
            log.save_csv_eval_log(opt, head_eval, write_ret_log, is_create=False)

        # 保存检查点
        log.save_ckpt(
            {
                'epoch': epoch,
                'lr1': lr1,
                'lr2': lr2,
                'err1': ret_valid['model1']['m_p3d_h36'],
                'err2': ret_valid['model2']['m_p3d_h36'],  # todo 待改
                'state_dict1': net_pred1.state_dict(),
                'state_dict2': net_pred2.state_dict(),
                'optimizer1': optimizer1.state_dict(),
                'optimizer2': optimizer2.state_dict()
            },
            is_best=is_best,
            opt=opt
        )


def eval(opt):
    """模型评估函数"""
    global ACTIONS
    ACTIONS = opt.actions or ACTIONS
    print('>>> 创建模型')
    set_seed(334)
    net_pred1 = BARNet(opt=opt)
    net_pred1.to(opt.cuda_idx)
    net_pred1.eval()

    set_seed(334)
    net_pred2 = model2.model.siMLPe(config=config)
    net_pred2.to(opt.cuda_idx)
    net_pred2.eval()

    # 加载模型
    
    model_path = './{}/ckpt_best.pth.tar'.format(opt.ckpt) if opt.is_eval else './{}/ckpt_last.pth.tar'.format(opt.ckpt)
    print(f">>> 从 '{model_path}' 加载检查点")
    ckpt = torch.load(model_path, map_location=torch.device('cpu'), weights_only=False)
    start_epoch = ckpt['epoch'] + 1
    err_best = ckpt['err1']
    net_pred1.load_state_dict(ckpt['state_dict1'])
    net_pred2.load_state_dict(ckpt['state_dict2'])

    print(f">>> 检查点加载完成 (epoch: {ckpt['epoch']} | err: {ckpt['err1']})")

    

    # 加载模型
    #model_path2 = 'model2\checkpoints\model-iter-40000.pth'
    #print(f">>> 从 '{model_path2}' 加载检查点")
    #state_dict = torch.load(model_path2, map_location='cpu')  # , weights_only=True
    #state_dict = {
    #    key.replace('motion_transformer.transformer.', 'motion_mlp.mlps.'): value
    #    for key, value in state_dict.items()
    #}
    #net_pred2.load_state_dict(state_dict, strict=True)
    # print(f">>> 检查点加载完成 (epoch: {ckpt['epoch']} | err: {ckpt['err2']})")

    if opt.result_dir:
        os.makedirs(opt.result_dir, exist_ok=True)
        opt.ckpt = opt.result_dir
    # 准备数据加载器
    data_loader = {}
    for action in ACTIONS:
        dataset = datasets.Datasets(opt=opt, split=2, actions=action)
        data_loader[action] = DataLoader(
            dataset,
            batch_size=opt.test_batch_size,
            shuffle=False,
            num_workers=0,
            pin_memory=True
        )

    # 执行评估
    is_create = True
    avg_ret_log = []
    for action in ACTIONS:
        ret_test = run_model(net_pred1, net_pred2=net_pred2, is_train=3, data_loader=data_loader[action], opt=opt, action=action)
        # 准备日志数据
        ret_log = [action]
        head = ['action']
        for key in ret_test["final"].keys():
            ret_log.append(ret_test["final"][key])
            head.append(f'test_{key}')

        avg_ret_log.append(ret_log[1:])
        log.save_csv_eval_log(opt, head, ret_log, is_create=is_create)
        is_create = False

    # 保存平均结果
    avg_ret_log = np.array(avg_ret_log, dtype=np.float64).mean(axis=0)
    write_ret_log = ret_log.copy()
    write_ret_log[0] = 'avg'
    write_ret_log[1:] = avg_ret_log
    log.save_csv_eval_log(opt, head, write_ret_log, is_create=False)


def run_model(net_pred1, net_pred2, optimizer1=None, optimizer2=None, is_train=0, data_loader=None, epo=None, opt=None,
              action=None):
    """
    运行模型训练/评估
    is_train: 0-训练, 1-验证, 3-测试
    """
    # 设置模型模式
    net_pred1.train() if is_train == 0 else net_pred1.eval()
    net_pred2.train() if is_train == 0 else net_pred2.eval()
    # 初始化变量
    l_p3d1 = 0
    l_p3d2 = 0
    l_p3d = 0

    if is_train <= 1:
        m_p3d_h36_1 = 0
        m_p3d_h36_2 = 0
        m_p3d_h36 = 0
        m_p3d_h36_show = torch.zeros([opt.output_n], device='cpu')
        m_p3d_h36_show1 = torch.zeros([opt.output_n], device='cpu')
        m_p3d_h36_show2 = torch.zeros([opt.output_n], device='cpu')
        m_p3d_h36_show3 = torch.zeros([opt.output_n], device='cpu')
    else:
        titles = (np.arange(opt.test_length) + 1) * 40
        m_p3d_h36_1 = np.zeros(opt.test_length)
        m_p3d_h36_2 = np.zeros(opt.test_length)
        m_p3d_h36 = np.zeros(opt.test_length)
        m_p3d_h36_show = torch.zeros([opt.test_length], device='cpu')
        m_p3d_h36_show1 = torch.zeros([opt.test_length], device='cpu')
        m_p3d_h36_show2 = torch.zeros([opt.test_length], device='cpu')
        m_p3d_h36_show3 = torch.zeros([opt.test_length], device='cpu')

    previous_grad_enabled = torch.is_grad_enabled()
    n = 0
    nb_iter = 0
    in_n = opt.input_n
    out_n = opt.output_n
    seq_in = opt.kernel_size
    start_time = time.time()
    # Validation/test do not need autograd.
    # 遍历数据加载器
    for i, (p3d_h36) in enumerate(data_loader):
        if opt.max_batches and i >= opt.max_batches:
            break
        # print(i)
        batch_size, seq_n, all_dim = p3d_h36.shape
        # 跳过单样本批次（训练时）
        if batch_size == 1 and is_train == 0:
            continue
        n += batch_size
        nb_iter += 1
        batch_time = time.time()

        torch.set_grad_enabled(is_train == 0)
        p3d_h36 = p3d_h36.float().to(opt.cuda_idx)
        # 数据预处理器
        node1 = p3d_h36[:, :, [3, 4, 5]].unsqueeze(2)
        node6 = p3d_h36[:, :, [18, 19, 20]].unsqueeze(2)

        fix = torch.tensor([0., 0.1, 0.], device=opt.cuda_idx).view(1, 1, 1, 3).expand(opt.batch_size, opt.dct_n, 22, 3).clone()
        geo1 = GEOMETRIC(leg_right=node1, leg_left=node6, fix=fix, opt=opt)
        geo1_target = GEOMETRIC(leg_right=node1, leg_left=node6, fix=fix, opt=opt)
        fix1 = torch.tensor([0.1, 0., 0.], device=opt.cuda_idx).view(1, 1, 1, 3).expand(opt.batch_size, opt.dct_n, 22,3).clone()
        geo2 = GEOMETRIC(leg_right=node1, leg_left=node6, fix=fix1, opt=opt)
        geo2_target = GEOMETRIC(leg_right=node1, leg_left=node6, fix=fix1, opt=opt)

        # 准备输入数据
        input_data = p3d_h36[:, :, DIM_USED].clone()
        # print(input_data[0,0,:])
        input_data_geo1 = geo1.encode(input_data)
        input_data_geo2 = geo2.encode(input_data)
        if is_train <= 1:
            p3d_sup = p3d_h36.clone()[:, :, DIM_USED][:, -out_n - in_n:]
            p3d_sup_geo1 = geo1_target.encode(p3d_sup)
            p3d_sup_geo2 = geo2_target.encode(p3d_sup)
            p3d_sup = p3d_sup.reshape([-1, in_n + out_n, len(DIM_USED) // 3, 3])

        # p3d_h36 = p3d_h36.reshape(batch_size, seq_n, all_dim // 3, -1)
        # h36m_motion_input = p3d_h36[:, :opt.input_n, joint_used_xyz].clone().reshape(batch_size, opt.input_n, -1)

        # 前向传播

        if is_train <= 1:
            # 训练输出 (bs,35,22,3)
            outputs_geo1 = net_pred1(input_data_geo1[:,:in_n])
            outputs_geo2 = train_one(input_data_geo2[:,:in_n],net_pred2,config)
        else:

            # outputs_geo1 = net_pred1(input_data_geo1[:, :in_n]) #
            # outputs_geo2 = test_one(input_data_geo2[:, :in_n], net_pred2, config)
            # 测试输出 (bs,110,22,3)
            outputs_geo1_list = [] # 存放预测结果
            outputs_geo2_list = []
            # 计算迭代次数
            step = out_n
            if step == opt.test_length:
                num_idx = 1
            else:
                num_idx = opt.test_length // step
            # 保存输入数据
            input_data_geo1_ = input_data_geo1.clone() #[:, :in_n]
            input_data_geo2_ = input_data_geo2[:, :in_n].clone()
            for idx in range(num_idx):
                # with torch.no_grad():
                    # 输入模型，输出结果 (bs,10,22,3) -> (bs,35,22,3)
                    outputs_geo1 = net_pred1(input_data_geo1_)
                    outputs_geo2 = test_one(input_data_geo2_, net_pred2,config)
                    # 第一次保留属于输入部分的十帧 其他只保留输出的25帧
                    outputs_geo1_list.append(outputs_geo1 if idx == 0 else outputs_geo1[:,-out_n:])
                    outputs_geo2_list.append(outputs_geo2 if idx == 0 else outputs_geo2[:,-out_n:])
                    #更新输入为上一次预测的后十帧
                    input_data_geo1_ = outputs_geo1[:,-in_n:].clone()
                    input_data_geo2_ = outputs_geo2[:, -in_n:].clone()
            # 拼接结果  若out_n = 25 and test_length = 100   ->   num_idx = 4 -> (35 + 25 + 25 + 25) = 110
            outputs_geo1 = torch.cat(outputs_geo1_list, dim=1) # (bs,110,66)
            outputs_geo2 = torch.cat(outputs_geo2_list, dim=1)

        # b,seq_2,c = outputs_geo2.shape
        # outputs_geo2 = net_pred2(input_data_geo2)
        # model2 前向传播
        # pbar = [(p3d_h36[:, :in_n].clone().reshape(batch_size, in_n, all_dim // 3, -1),p3d_h36.clone()[:, in_n:in_n + out_n].reshape(batch_size, out_n, all_dim // 3, -1))]
        # net_pred2.eval()

        # m_p3d_h36_2_t, motion_pred = regress_pred(net_pred2, pbar, num_samples, joint_used_xyz, m_p3d_h36_2_t)
        # ret = {}
        # titles1 = np.array(range(config.motion.h36m_target_length_eval)) + 1
        # for j in range(config.motion.h36m_target_length_eval):
        #     ret["#{:d}".format(titles1[j])] = [m_p3d_h36_2_t[j], m_p3d_h36_2_t[j]]
        # results_keys = ['#2', '#4', '#8', '#10', '#14', '#18', '#22', '#25']
        # if nb_iter % 800 == 0 and is_train == 3:
        #     print("model2:",[round(ret[key][0], 1) for key in results_keys])
        # motion_pred = torch.cat([p3d_h36[:,:in_n].clone().reshape(batch_size, opt.input_n,-1),motion_pred], dim=1)
        # print(motion_pred.shape)
        # motion_pred_geo = geo2.encode(motion_pred[:,:,DIM_USED])
        # model2 前向传播

        # LEAK-02: decode reads future bones/refer cached by encode; metrics are oracle-assisted.
        # 数据还原
        # todo 后续只输出 u1,b11,b12  其他可能导致数据泄露的都删掉 暂时为了看到输出而保留
        # 训练 (bs,35,22,3) 测试 (bs,110,22,3)
        output1, u1, b11, b12, mask_1 = geo1.decode(outputs_geo1)  # p3d_out_all_fin
        output2, u2, b21, b22, mask_2 = geo2.decode(outputs_geo2)

        bs, seq, node_num,_ = b11.shape # 用于还原骨架的数据
        result1 = torch.einsum('ijkl,ijkl->ijk', b11, b21)  # bs,seq,22
        result2 = torch.einsum('ijkl,ijkl->ijk', b11, b22)
        result3 = torch.einsum('ijkl,ijkl->ijk', b12, b21)
        result4 = torch.einsum('ijkl,ijkl->ijk', b12, b22)
        dots = torch.stack([result1 + result2, result3 + result4], dim=-1)
        max_dots, max_idx = torch.max(dots, dim=-1)
        result_matrix = torch.where(max_idx.bool().unsqueeze(-1).expand(-1, -1, -1, 3), b12, b11)
        # (bs,35,66) / (bs,110,66)
        output = geo1.build_framework(data_class='h36m', node=node_num, bs=bs, seq=seq, dim=node_num * 3,result_matrix=result_matrix)

        out_bs,out_seq,out_dim = output.shape # 当前输出数据的形状
        pre_seq = out_seq - in_n

        # 处理输出
        p3d_out = p3d_h36.clone().reshape(batch_size, seq_n, -1)[:, in_n:out_seq]
        p3d_out1 = p3d_h36.clone().reshape(batch_size, seq_n, -1)[:, in_n:out_seq]
        p3d_out2 = p3d_h36.clone().reshape(batch_size, seq_n, -1)[:, in_n:out_seq]

        #final
        p3d_out[:, :, DIM_USED] = output[:, in_n:out_seq]
        p3d_out[:, :, INDEX_TO_IGNORE] = p3d_out[:, :, INDEX_TO_EQUAL]
        # model1_train
        p3d_out1[:, :, DIM_USED] = output1[:, in_n:out_seq]
        p3d_out1[:, :, INDEX_TO_IGNORE] = p3d_out1[:, :, INDEX_TO_EQUAL]
        # model2_train
        p3d_out2[:, :, DIM_USED] = output2[:, in_n:out_seq]
        p3d_out2[:, :, INDEX_TO_IGNORE] = p3d_out2[:, :, INDEX_TO_EQUAL]

        # 塑造维度
        p3d_out = p3d_out.reshape([-1, pre_seq, all_dim // 3, 3])
        p3d_out1 = p3d_out1.reshape([-1, pre_seq, all_dim // 3, 3])
        p3d_out2 = p3d_out2.reshape([-1, pre_seq, all_dim // 3, 3])

        p3d_h36 = p3d_h36.reshape([-1, seq_n, all_dim // 3, 3])

        # 重塑输出
        if is_train <= 1:
            p3d_sup_geo1 = p3d_sup_geo1.reshape([batch_size, in_n + out_n, len(DIM_USED) // 3, 3])
            p3d_sup_geo2 = p3d_sup_geo2.reshape([batch_size, in_n + out_n, len(DIM_USED) // 3, 3])

        outputs_geo1 = outputs_geo1.reshape([batch_size, out_seq, len(DIM_USED) // 3, 3])
        outputs_geo2 = outputs_geo2.reshape([batch_size, out_seq, len(DIM_USED) // 3, 3])
        output = output.reshape([batch_size, out_seq, len(DIM_USED) // 3, 3])
        output1 = output1.reshape([batch_size, out_seq, len(DIM_USED) // 3, 3])
        output2 = output2.reshape([batch_size, out_seq, len(DIM_USED) // 3, 3])

        # 训练步骤
        if is_train == 0:
            # 计算损失
            loss = torch.mean(torch.norm(output - p3d_sup, dim=3))
            loss_geo1 = torch.mean(torch.norm(outputs_geo1 - p3d_sup_geo1, dim=3))
            loss1 = torch.mean(torch.norm(output1 - p3d_sup, dim=3))

            loss_geo2 = torch.mean(torch.norm(outputs_geo2 - p3d_sup_geo2, dim=3)) #[:,:seq_2]
            loss2 = torch.mean(torch.norm(output2 - p3d_sup, dim=3))#[:,:seq_2]

            optimizer1.zero_grad()
            (loss_geo1 + loss_geo2).backward()
            # loss.backward()
            nn.utils.clip_grad_norm_(net_pred1.parameters(), max_norm=opt.max_norm)
            nn.utils.clip_grad_norm_(net_pred2.parameters(), max_norm=opt.max_norm)
            optimizer1.step()

            # optimizer2.zero_grad()
            # loss_geo2.backward()

            # optimizer2.step()

            # 更新日志
            l_p3d1 += loss1.cpu().data.numpy() * batch_size
            l_p3d2 += loss2.cpu().data.numpy() * batch_size
            l_p3d  += loss.cpu().data.numpy() * batch_size
        # 计算误差
        if is_train <= 1:
        # 仅统计指标，不记录计算图
            with torch.no_grad():
                target = p3d_h36[:, in_n:in_n + pre_seq]
                mpjpe1 = torch.norm(target - p3d_out1, dim=3).mean(dim=2)
                mpjpe2 = torch.norm(target - p3d_out2, dim=3).mean(dim=2)
                mpjpe = torch.norm(target - p3d_out, dim=3).mean(dim=2)
                m_p3d_h36_1 += mpjpe1.mean().item() * batch_size
                m_p3d_h36_2 += mpjpe2.mean().item() * batch_size
                m_p3d_h36 += mpjpe.mean().item() * batch_size
                m_p3d_h36_show1 += mpjpe1.sum(dim=0).cpu()
                m_p3d_h36_show2 += mpjpe2.sum(dim=0).cpu() #[:seq_2-in_n]
                m_p3d_h36_show3 += mpjpe.sum(dim=0).cpu()
                if i % 1000 == 0:
                    indices = [1, 3, 7, 9, 13, 17, 21, 24] #,49,74,99
                    indices = [index for index in indices if index < pre_seq]
                    print("model1:", m_p3d_h36_show1[indices] / n)
                    print("model2:", m_p3d_h36_show2[indices] / n)
                    print("model3:", m_p3d_h36_show3[indices] / n)

        else:
            # 计算每个时间步的位置误差
            with torch.no_grad():
                target = p3d_h36[:, in_n:in_n + pre_seq]
                mpjpe1 = torch.norm(target - p3d_out1, dim=3).mean(dim=2).sum(dim=0).cpu()
                mpjpe2 = torch.norm(target - p3d_out2, dim=3).mean(dim=2).sum(dim=0).cpu()
                mpjpe = torch.norm(target - p3d_out, dim=3).mean(dim=2).sum(dim=0).cpu()
                m_p3d_h36_1 += mpjpe1.numpy()
                m_p3d_h36_2 += mpjpe2.numpy()
                m_p3d_h36 += mpjpe.numpy()
                m_p3d_h36_show1 += mpjpe1
                m_p3d_h36_show2 += mpjpe2
                m_p3d_h36_show3 += mpjpe
                if i % 1000 == 0:
                    indices = [1, 3, 7, 9, 13, 17, 21, 24] #,49,74,99
                    indices = [index for index in indices if index < pre_seq]
                    print("model1:", m_p3d_h36_show1[indices] / n)
                    print("model2:", m_p3d_h36_show2[indices] / n)
                    print("model3:", m_p3d_h36_show3[indices] / n)



        # 打印进度
        if i % 1000 == 0:
            elapsed = time.time() - start_time
            print(f'{i + 1}/{len(data_loader)} | '
                  f'批次时间: {time.time() - batch_time:.3f}s | '
                  f'总时间: {elapsed:.0f}s')

    # 准备返回结果
    ret = {
        'model1': {
            'l_p3d':0,
            'm_p3d_h36':0,
        },
        'model2': {
            'l_p3d': 0,
            'm_p3d_h36': 0,
        },
        'final': {
            'l_p3d': 0,
            'm_p3d_h36': 0,
        }
    }
    if is_train == 0:
        ret["model1"]["l_p3d"] = l_p3d1 / n
        ret["model2"]["l_p3d"] = l_p3d2 / n
        ret["final"]["l_p3d"] = l_p3d / n

    if is_train <= 1:
        ret["model1"]["m_p3d_h36"] = m_p3d_h36_1 / n
        ret["model2"]["m_p3d_h36"] = m_p3d_h36_2 / n
        ret["final"]["m_p3d_h36"] = m_p3d_h36 / n
    else:
        m_p3d_h36_1 /= n
        m_p3d_h36_2 /= n
        m_p3d_h36 /= n

        for j in range(opt.test_length):
            ret["model1"][f"#{titles[j]}ms"] = m_p3d_h36_1[j]
            ret["model2"][f"#{titles[j]}ms"] = m_p3d_h36_2[j]
            ret["final"][f"#{titles[j]}ms"] = m_p3d_h36[j]

    torch.set_grad_enabled(previous_grad_enabled)
    return ret


if __name__ == '__main__':
    # 初始化配置和全局变量
    option = Options().parse()
    global_var._init()
    if option.input_n != 10 or option.kernel_size != 10:
        raise ValueError('This architecture requires --input_n 10 --kernel_size 10')
    if option.dct_n != option.input_n + option.output_n:
        raise ValueError('--dct_n must equal --input_n + --output_n')
    if option.output_n < 1 or option.test_length < 1 or option.test_length % option.output_n:
        raise ValueError('--test_length must be a positive multiple of --output_n')
    if not option.is_eval and option.test_length != option.output_n:
        raise ValueError('Training-time evaluation requires --test_length == --output_n')
    # Keep siMLPe temporal dimensions and its cached DCT matrices in sync with CLI.
    import model2.train as train_module
    import model2.test as test_module
    for name in ['h36m_input_length', 'h36m_input_length_dct',
                 'h36m_target_length_train', 'h36m_target_length_eval']:
        setattr(config.motion, name, option.dct_n)
    config.motion_mlp.seq_len = option.dct_n
    for module in [train_module, test_module]:
        dct, idct = module.get_dct_matrix(option.dct_n)
        module.dct_m = torch.tensor(dct, device=option.cuda_idx).float().unsqueeze(0)
        module.idct_m = torch.tensor(idct, device=option.cuda_idx).float().unsqueeze(0)
    config.motion_fc_in.temporal_fc = option.temporal_only
    config.motion_fc_out.temporal_fc = option.temporal_only
    config.motion_mlp.norm_axis = option.layer_norm_axis
    config.motion_mlp.spatial_fc_only = option.spatial_fc
    config.motion_mlp.with_normalization = option.with_normalization
    config.motion_mlp.num_layers = option.num
    set_seed(334)
    torch.cuda.set_device(option.cuda_idx)
    # 执行主程序
    if option.is_eval:
        eval(option)
    else:
        main(option)